package game_1;

public class ExecClass {
	public static void main(String[] args) {
	GameManager gameManager = new GameManager();
	gameManager.play();
	}
}
